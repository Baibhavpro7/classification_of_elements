import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

type Block = "s" | "p" | "d" | "f";

type ElementData = {
  atomicNumber: number;
  symbol: string;
  name: string;
  group: number;
  period: number;
  block: Block;
  subshell: string;
  shell: string;
  valency: string;
  outerElectrons: number;
  losesGains: string;
  why: string;
  traits: string;
};

type Question = {
  prompt: string;
  options: string[];
  answer: number;
  explanation: string;
};

const blockColors: Record<Block, string> = {
  s: "border-[#4cc9ff] bg-[#4cc9ff1a] text-[#96e6ff]",
  p: "border-[#37f28f] bg-[#37f28f1a] text-[#93ffbd]",
  d: "border-[#ffd166] bg-[#ffd1661a] text-[#ffe5a3]",
  f: "border-[#b388ff] bg-[#b388ff1a] text-[#d4b8ff]",
};

const nobleGases = new Set(["He", "Ne", "Ar", "Kr", "Xe", "Rn", "Og"]);

const masteryElements: ElementData[] = [
  {
    atomicNumber: 1,
    symbol: "H",
    name: "Hydrogen",
    group: 1,
    period: 1,
    block: "s",
    subshell: "1s1",
    shell: "K1",
    valency: "1",
    outerElectrons: 1,
    losesGains: "Can lose 1 or gain 1 electron",
    why: "Atomic number 1 means one electron in 1s, so it starts Group 1 and Period 1.",
    traits: "Unique non-metal placed above alkali metals due to one valence electron.",
  },
  {
    atomicNumber: 2,
    symbol: "He",
    name: "Helium",
    group: 18,
    period: 1,
    block: "s",
    subshell: "1s2",
    shell: "K2",
    valency: "0",
    outerElectrons: 2,
    losesGains: "Stable duplet, no electron exchange",
    why: "Complete first shell gives noble gas stability, so it sits in Group 18.",
    traits: "Chemically inert noble gas with complete valence shell.",
  },
  {
    atomicNumber: 3,
    symbol: "Li",
    name: "Lithium",
    group: 1,
    period: 2,
    block: "s",
    subshell: "1s2 2s1",
    shell: "K2 L1",
    valency: "1",
    outerElectrons: 1,
    losesGains: "Loses 1 electron",
    why: "New shell starts at n=2 and one valence electron places it in Group 1.",
    traits: "Alkali metal, highly electropositive.",
  },
  {
    atomicNumber: 4,
    symbol: "Be",
    name: "Beryllium",
    group: 2,
    period: 2,
    block: "s",
    subshell: "1s2 2s2",
    shell: "K2 L2",
    valency: "2",
    outerElectrons: 2,
    losesGains: "Loses 2 electrons",
    why: "Two electrons in the outer shell define Group 2 in Period 2.",
    traits: "Alkaline earth metal with stable +2 tendency.",
  },
  {
    atomicNumber: 5,
    symbol: "B",
    name: "Boron",
    group: 13,
    period: 2,
    block: "p",
    subshell: "1s2 2s2 2p1",
    shell: "K2 L3",
    valency: "3",
    outerElectrons: 3,
    losesGains: "Usually forms covalent bonds",
    why: "Last electron enters p-subshell; 3 valence electrons map to Group 13.",
    traits: "Metalloid at the border of metals and non-metals.",
  },
  {
    atomicNumber: 6,
    symbol: "C",
    name: "Carbon",
    group: 14,
    period: 2,
    block: "p",
    subshell: "1s2 2s2 2p2",
    shell: "K2 L4",
    valency: "4",
    outerElectrons: 4,
    losesGains: "Shares electrons",
    why: "Four valence electrons place it in Group 14 with strong covalent behavior.",
    traits: "Core element for organic chemistry.",
  },
  {
    atomicNumber: 7,
    symbol: "N",
    name: "Nitrogen",
    group: 15,
    period: 2,
    block: "p",
    subshell: "1s2 2s2 2p3",
    shell: "K2 L5",
    valency: "3,5",
    outerElectrons: 5,
    losesGains: "Gains 3 or shares",
    why: "Half-filled p-subshell gives special stability and Group 15 placement.",
    traits: "Non-metal showing variable valency.",
  },
  {
    atomicNumber: 8,
    symbol: "O",
    name: "Oxygen",
    group: 16,
    period: 2,
    block: "p",
    subshell: "1s2 2s2 2p4",
    shell: "K2 L6",
    valency: "2",
    outerElectrons: 6,
    losesGains: "Gains 2 electrons",
    why: "Six valence electrons require two more for octet, giving Group 16 identity.",
    traits: "Highly electronegative non-metal.",
  },
  {
    atomicNumber: 9,
    symbol: "F",
    name: "Fluorine",
    group: 17,
    period: 2,
    block: "p",
    subshell: "1s2 2s2 2p5",
    shell: "K2 L7",
    valency: "1",
    outerElectrons: 7,
    losesGains: "Gains 1 electron",
    why: "Seven valence electrons make it a halogen in Group 17.",
    traits: "Most reactive non-metal in the periodic table.",
  },
  {
    atomicNumber: 10,
    symbol: "Ne",
    name: "Neon",
    group: 18,
    period: 2,
    block: "p",
    subshell: "1s2 2s2 2p6",
    shell: "K2 L8",
    valency: "0",
    outerElectrons: 8,
    losesGains: "Already stable octet",
    why: "Complete octet pushes it to inert Group 18.",
    traits: "Noble gas with very low reactivity.",
  },
  {
    atomicNumber: 11,
    symbol: "Na",
    name: "Sodium",
    group: 1,
    period: 3,
    block: "s",
    subshell: "1s2 2s2 2p6 3s1",
    shell: "K2 L8 M1",
    valency: "1",
    outerElectrons: 1,
    losesGains: "Loses 1 electron to form Na+",
    why: "A single 3s electron places Na in Group 1, Period 3.",
    traits: "Highly reactive alkali metal.",
  },
  {
    atomicNumber: 12,
    symbol: "Mg",
    name: "Magnesium",
    group: 2,
    period: 3,
    block: "s",
    subshell: "1s2 2s2 2p6 3s2",
    shell: "K2 L8 M2",
    valency: "2",
    outerElectrons: 2,
    losesGains: "Loses 2 electrons to form Mg2+",
    why: "Two outer electrons in shell 3 fix it in Group 2.",
    traits: "Forms stable Mg2+ due to noble gas core after loss.",
  },
  {
    atomicNumber: 13,
    symbol: "Al",
    name: "Aluminium",
    group: 13,
    period: 3,
    block: "p",
    subshell: "1s2 2s2 2p6 3s2 3p1",
    shell: "K2 L8 M3",
    valency: "3",
    outerElectrons: 3,
    losesGains: "Loses 3 electrons",
    why: "Three valence electrons and p-block entry decide Group 13.",
    traits: "Light metal with amphoteric oxide.",
  },
  {
    atomicNumber: 14,
    symbol: "Si",
    name: "Silicon",
    group: 14,
    period: 3,
    block: "p",
    subshell: "1s2 2s2 2p6 3s2 3p2",
    shell: "K2 L8 M4",
    valency: "4",
    outerElectrons: 4,
    losesGains: "Shares electrons",
    why: "Outer-shell count of four maps to Group 14.",
    traits: "Metalloid used in semiconductors.",
  },
  {
    atomicNumber: 15,
    symbol: "P",
    name: "Phosphorus",
    group: 15,
    period: 3,
    block: "p",
    subshell: "1s2 2s2 2p6 3s2 3p3",
    shell: "K2 L8 M5",
    valency: "3,5",
    outerElectrons: 5,
    losesGains: "Shares or gains electrons",
    why: "Five valence electrons define Group 15 behavior.",
    traits: "Non-metal with multiple oxidation states.",
  },
  {
    atomicNumber: 16,
    symbol: "S",
    name: "Sulfur",
    group: 16,
    period: 3,
    block: "p",
    subshell: "1s2 2s2 2p6 3s2 3p4",
    shell: "K2 L8 M6",
    valency: "2,4,6",
    outerElectrons: 6,
    losesGains: "Usually gains 2 or shares",
    why: "Six valence electrons place sulfur in Group 16.",
    traits: "Typical non-metal with variable valency.",
  },
  {
    atomicNumber: 17,
    symbol: "Cl",
    name: "Chlorine",
    group: 17,
    period: 3,
    block: "p",
    subshell: "1s2 2s2 2p6 3s2 3p5",
    shell: "K2 L8 M7",
    valency: "1,3,5,7",
    outerElectrons: 7,
    losesGains: "Gains 1 or shares electrons",
    why: "Seven outer electrons put chlorine in halogen Group 17.",
    traits: "Very reactive non-metal used in disinfection.",
  },
  {
    atomicNumber: 18,
    symbol: "Ar",
    name: "Argon",
    group: 18,
    period: 3,
    block: "p",
    subshell: "1s2 2s2 2p6 3s2 3p6",
    shell: "K2 L8 M8",
    valency: "0",
    outerElectrons: 8,
    losesGains: "No gain or loss",
    why: "Full octet in shell M makes argon a noble gas.",
    traits: "Inert gas used in bulbs and welding.",
  },
  {
    atomicNumber: 19,
    symbol: "K",
    name: "Potassium",
    group: 1,
    period: 4,
    block: "s",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s1",
    shell: "K2 L8 M8 N1",
    valency: "1",
    outerElectrons: 1,
    losesGains: "Loses 1 electron very easily",
    why: "Electron enters new shell 4s, so period increases to 4 while group stays 1.",
    traits: "More reactive than sodium because valence electron is farther out.",
  },
  {
    atomicNumber: 20,
    symbol: "Ca",
    name: "Calcium",
    group: 2,
    period: 4,
    block: "s",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s2",
    shell: "K2 L8 M8 N2",
    valency: "2",
    outerElectrons: 2,
    losesGains: "Loses 2 electrons",
    why: "Two 4s electrons define Group 2, Period 4.",
    traits: "Important alkaline earth metal in biology.",
  },
  {
    atomicNumber: 21,
    symbol: "Sc",
    name: "Scandium",
    group: 3,
    period: 4,
    block: "d",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s2 3d1",
    shell: "K2 L8 M9 N2",
    valency: "3",
    outerElectrons: 2,
    losesGains: "Loses 3 electrons",
    why: "Entry into d-subshell marks the start of transition series.",
    traits: "First transition element in period 4.",
  },
  {
    atomicNumber: 22,
    symbol: "Ti",
    name: "Titanium",
    group: 4,
    period: 4,
    block: "d",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s2 3d2",
    shell: "K2 L8 M10 N2",
    valency: "4",
    outerElectrons: 2,
    losesGains: "Loses 2 to 4 electrons",
    why: "d-block occupancy determines Group 4 transition behavior.",
    traits: "Strong corrosion-resistant transition metal.",
  },
  {
    atomicNumber: 23,
    symbol: "V",
    name: "Vanadium",
    group: 5,
    period: 4,
    block: "d",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s2 3d3",
    shell: "K2 L8 M11 N2",
    valency: "5",
    outerElectrons: 2,
    losesGains: "Shows variable valency",
    why: "Three d-electrons plus two s-electrons place it in Group 5.",
    traits: "Transition element with multiple oxidation states.",
  },
  {
    atomicNumber: 24,
    symbol: "Cr",
    name: "Chromium",
    group: 6,
    period: 4,
    block: "d",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s1 3d5",
    shell: "K2 L8 M13 N1",
    valency: "2,3,6",
    outerElectrons: 1,
    losesGains: "Variable electron loss",
    why: "Half-filled 3d5 arrangement is extra stable, creating an exception.",
    traits: "Aufbau anomaly with half-filled d-subshell stability.",
  },
  {
    atomicNumber: 25,
    symbol: "Mn",
    name: "Manganese",
    group: 7,
    period: 4,
    block: "d",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s2 3d5",
    shell: "K2 L8 M13 N2",
    valency: "2,4,7",
    outerElectrons: 2,
    losesGains: "Variable electron loss",
    why: "d-block placement and five d-electrons explain broad valency.",
    traits: "Transition element with many oxidation states.",
  },
  {
    atomicNumber: 26,
    symbol: "Fe",
    name: "Iron",
    group: 8,
    period: 4,
    block: "d",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s2 3d6",
    shell: "K2 L8 M14 N2",
    valency: "2,3",
    outerElectrons: 2,
    losesGains: "Loses 2 or 3 electrons",
    why: "Partially filled d-subshell gives Group 8 transition behavior.",
    traits: "Core industrial metal linked to ores and extraction.",
  },
  {
    atomicNumber: 27,
    symbol: "Co",
    name: "Cobalt",
    group: 9,
    period: 4,
    block: "d",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s2 3d7",
    shell: "K2 L8 M15 N2",
    valency: "2,3",
    outerElectrons: 2,
    losesGains: "Loses 2 or 3 electrons",
    why: "d-electron count places cobalt in Group 9.",
    traits: "Hard transition metal used in alloys.",
  },
  {
    atomicNumber: 28,
    symbol: "Ni",
    name: "Nickel",
    group: 10,
    period: 4,
    block: "d",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s2 3d8",
    shell: "K2 L8 M16 N2",
    valency: "2",
    outerElectrons: 2,
    losesGains: "Mainly loses 2 electrons",
    why: "Transition filling pattern places Ni in Group 10.",
    traits: "Moderately reactive transition metal.",
  },
  {
    atomicNumber: 29,
    symbol: "Cu",
    name: "Copper",
    group: 11,
    period: 4,
    block: "d",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s1 3d10",
    shell: "K2 L8 M18 N1",
    valency: "1,2",
    outerElectrons: 1,
    losesGains: "Loses 1 or 2 electrons",
    why: "Fully filled 3d10 gives an Aufbau exception similar to chromium.",
    traits: "Good conductor with anomaly in electron arrangement.",
  },
  {
    atomicNumber: 30,
    symbol: "Zn",
    name: "Zinc",
    group: 12,
    period: 4,
    block: "d",
    subshell: "1s2 2s2 2p6 3s2 3p6 4s2 3d10",
    shell: "K2 L8 M18 N2",
    valency: "2",
    outerElectrons: 2,
    losesGains: "Loses 2 electrons",
    why: "Stable filled d-subshell and two 4s electrons identify Group 12.",
    traits: "Used in galvanization and displacement reactions.",
  },
  {
    atomicNumber: 47,
    symbol: "Ag",
    name: "Silver",
    group: 11,
    period: 5,
    block: "d",
    subshell: "[Kr] 4d10 5s1",
    shell: "K2 L8 M18 N18 O1",
    valency: "1",
    outerElectrons: 1,
    losesGains: "Loses 1 electron",
    why: "d-block coinage metal with one outer s-electron.",
    traits: "Connected to electro-refining in metallurgy.",
  },
  {
    atomicNumber: 79,
    symbol: "Au",
    name: "Gold",
    group: 11,
    period: 6,
    block: "d",
    subshell: "[Xe] 4f14 5d10 6s1",
    shell: "K2 L8 M18 N32 O18 P1",
    valency: "1,3",
    outerElectrons: 1,
    losesGains: "Loses 1 or 3 electrons",
    why: "Coinage metal with filled d-subshell and one outer electron.",
    traits: "Noble transition metal with very low reactivity.",
  },
  {
    atomicNumber: 80,
    symbol: "Hg",
    name: "Mercury",
    group: 12,
    period: 6,
    block: "d",
    subshell: "[Xe] 4f14 5d10 6s2",
    shell: "K2 L8 M18 N32 O18 P2",
    valency: "1,2",
    outerElectrons: 2,
    losesGains: "Loses 1 or 2 electrons",
    why: "Filled 5d10 and 6s2 shell place mercury in Group 12.",
    traits: "Heavy liquid metal and SEE-relevant exception case.",
  },
];

const symbolOrder = [
  "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
];

const symbolToAtomic = Object.fromEntries(symbolOrder.map((symbol, index) => [symbol, index + 1]));

const makeRow = (entries: Record<number, string>) =>
  Array.from({ length: 18 }, (_, index) => entries[index + 1] ?? "");

const periodRows = [
  makeRow({ 1: "H", 18: "He" }),
  makeRow({ 1: "Li", 2: "Be", 13: "B", 14: "C", 15: "N", 16: "O", 17: "F", 18: "Ne" }),
  makeRow({ 1: "Na", 2: "Mg", 13: "Al", 14: "Si", 15: "P", 16: "S", 17: "Cl", 18: "Ar" }),
  makeRow({ 1: "K", 2: "Ca", 3: "Sc", 4: "Ti", 5: "V", 6: "Cr", 7: "Mn", 8: "Fe", 9: "Co", 10: "Ni", 11: "Cu", 12: "Zn", 13: "Ga", 14: "Ge", 15: "As", 16: "Se", 17: "Br", 18: "Kr" }),
  makeRow({ 1: "Rb", 2: "Sr", 3: "Y", 4: "Zr", 5: "Nb", 6: "Mo", 7: "Tc", 8: "Ru", 9: "Rh", 10: "Pd", 11: "Ag", 12: "Cd", 13: "In", 14: "Sn", 15: "Sb", 16: "Te", 17: "I", 18: "Xe" }),
  makeRow({ 1: "Cs", 2: "Ba", 3: "La", 4: "Hf", 5: "Ta", 6: "W", 7: "Re", 8: "Os", 9: "Ir", 10: "Pt", 11: "Au", 12: "Hg", 13: "Tl", 14: "Pb", 15: "Bi", 16: "Po", 17: "At", 18: "Rn" }),
  makeRow({ 1: "Fr", 2: "Ra", 3: "Ac", 4: "Rf", 5: "Db", 6: "Sg", 7: "Bh", 8: "Hs", 9: "Mt", 10: "Ds", 11: "Rg", 12: "Cn", 13: "Nh", 14: "Fl", 15: "Mc", 16: "Lv", 17: "Ts", 18: "Og" }),
];

const lanthanides = ["Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu"];
const actinides = ["Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr"];

const orbitalOrder = [
  { name: "1s", capacity: 2 },
  { name: "2s", capacity: 2 },
  { name: "2p", capacity: 6 },
  { name: "3s", capacity: 2 },
  { name: "3p", capacity: 6 },
  { name: "4s", capacity: 2 },
  { name: "3d", capacity: 10 },
  { name: "4p", capacity: 6 },
  { name: "5s", capacity: 2 },
  { name: "4d", capacity: 10 },
  { name: "5p", capacity: 6 },
  { name: "6s", capacity: 2 },
  { name: "4f", capacity: 14 },
  { name: "5d", capacity: 10 },
  { name: "6p", capacity: 6 },
  { name: "7s", capacity: 2 },
];

const quizBank: Question[] = [
  {
    prompt: "Modern Periodic Law states that properties of elements are periodic functions of:",
    options: ["Atomic mass", "Atomic number", "Valency only", "Density"],
    answer: 1,
    explanation: "Moseley proved periodicity depends on atomic number, not atomic mass.",
  },
  {
    prompt: "Sodium belongs to Group 1 because it has:",
    options: ["1 valence electron", "2 valence electrons", "3 shells", "Atomic number 1"],
    answer: 0,
    explanation: "Group is linked to valence electron pattern in main-group elements.",
  },
  {
    prompt: "Across Period 3, atomic radius generally:",
    options: ["Increases", "Stays the same", "Decreases", "First increases then decreases"],
    answer: 2,
    explanation: "Nuclear charge increases while shell count stays the same, pulling electrons inward.",
  },
  {
    prompt: "Down Group 1, reactivity of alkali metals:",
    options: ["Decreases", "Increases", "Does not change", "Becomes zero"],
    answer: 1,
    explanation: "Valence electron gets farther from nucleus and is lost more easily.",
  },
  {
    prompt: "Which is the correct valency of magnesium in MgCl2?",
    options: ["1", "2", "3", "0"],
    answer: 1,
    explanation: "Magnesium loses two electrons to form Mg2+.",
  },
  {
    prompt: "Halogens are found in:",
    options: ["Group 1", "Group 2", "Group 17", "Group 18"],
    answer: 2,
    explanation: "Halogens have 7 valence electrons and occupy Group 17.",
  },
  {
    prompt: "Noble gases are generally unreactive because:",
    options: ["They are metals", "They have full valence shells", "They are very heavy", "They have no protons"],
    answer: 1,
    explanation: "Their duplet/octet is complete, so they have little tendency to gain or lose electrons.",
  },
  {
    prompt: "The sub-shell filled after 3p in normal Aufbau order is:",
    options: ["3d", "4p", "4s", "5s"],
    answer: 2,
    explanation: "Energy order is 3p then 4s, then 3d.",
  },
  {
    prompt: "Which pair demonstrates Mendeleev's atomic mass anomaly fixed by modern table?",
    options: ["Na and Mg", "Ar and K", "Cl and S", "C and N"],
    answer: 1,
    explanation: "Ar/K were awkward in mass order but correct in atomic-number order.",
  },
  {
    prompt: "Transition elements mainly occupy which block?",
    options: ["s-block", "p-block", "d-block", "f-block"],
    answer: 2,
    explanation: "d-block contains transition elements.",
  },
  {
    prompt: "Which element is more reactive as a non-metal?",
    options: ["Iodine", "Fluorine", "Bromine", "Sulfur"],
    answer: 1,
    explanation: "Fluorine has smallest size and strongest pull for an extra electron.",
  },
  {
    prompt: "Valence electrons of chlorine are:",
    options: ["5", "6", "7", "8"],
    answer: 2,
    explanation: "Cl configuration ends in 3s2 3p5, making 7 valence electrons.",
  },
  {
    prompt: "Why does potassium form K+ instead of K2+?",
    options: ["Second electron is in nucleus", "K has no second electron", "Removing second electron breaks stable octet shell", "K is inert"],
    answer: 2,
    explanation: "After losing one electron, K gets Argon-like stable shell; removing another is highly unfavorable.",
  },
  {
    prompt: "Which is an s-block pair?",
    options: ["Na and Mg", "Al and Si", "Fe and Cu", "F and Cl"],
    answer: 0,
    explanation: "Na and Mg are in groups 1 and 2 (s-block).",
  },
  {
    prompt: "Atomic number of zinc (Zn) is:",
    options: ["28", "29", "30", "31"],
    answer: 2,
    explanation: "Zn is element number 30.",
  },
  {
    prompt: "In Period 3, which has the smallest atomic radius?",
    options: ["Na", "Mg", "Cl", "Ar"],
    answer: 3,
    explanation: "Radius decreases across period, so Ar is smallest among these.",
  },
  {
    prompt: "Valency of oxygen is usually:",
    options: ["1", "2", "3", "4"],
    answer: 1,
    explanation: "Oxygen needs two electrons to complete octet.",
  },
  {
    prompt: "Which element is used in SEE questions for electro-refining?",
    options: ["Iron", "Silver", "Sodium", "Helium"],
    answer: 1,
    explanation: "Silver refining by electrolysis is a standard metallurgy case.",
  },
  {
    prompt: "Which statement is true for p-block elements?",
    options: ["Only metals", "Only non-metals", "Includes metals, metalloids, and non-metals", "Contains noble gases only"],
    answer: 2,
    explanation: "p-block spans many chemical types, including all three categories.",
  },
  {
    prompt: "The valency of neon is:",
    options: ["0", "1", "2", "8"],
    answer: 0,
    explanation: "Neon has complete octet and usually does not form compounds.",
  },
];

const studyTopics = [
  { id: "modern-law", label: "Modern periodic law" },
  { id: "group-period", label: "Group and period logic" },
  { id: "electronic-config", label: "Electronic configuration" },
  { id: "valency", label: "Valency and ions" },
  { id: "trends", label: "Atomic radius and reactivity trends" },
  { id: "blocks", label: "s, p, d, f block classification" },
  { id: "metallurgy-link", label: "Link to metallurgy" },
  { id: "equations", label: "Equation balancing" },
];

const conceptNotes = {
  "period-vs-group": {
    title: "Period vs Group",
    text: "Period is horizontal and tells number of shells. Group is vertical and tells valence-electron pattern for main-group elements.",
    exam: "SEE asks direct identification questions like period/group from atomic number or shell configuration.",
  },
  "valence-vs-valency": {
    title: "Valence Electrons vs Valency",
    text: "Valence electrons are electrons in outermost shell. Valency is combining capacity based on how many electrons are lost, gained, or shared.",
    exam: "Common MCQ: identify valency from configuration such as 2,8,1 or 2,8,7.",
  },
  "metal-vs-nonmetal": {
    title: "Metal vs Non-metal Reactivity",
    text: "Metals become more reactive down a group because electron loss becomes easier. Non-metals become more reactive up a group because electron gain becomes easier.",
    exam: "Very common short answer: compare Na/K or F/I with reasoning.",
  },
  "anomaly-ar-k": {
    title: "Ar-K Anomaly",
    text: "Mass order placed K before Ar, but chemical properties demanded Ar in noble gases and K in alkali metals. Atomic-number order solved this.",
    exam: "Expected as one-mark conceptual contrast between old and modern tables.",
  },
} as const;

const classificationPairs = [
  { key: "alkali", prompt: "Alkali metals belong to", expected: "Group 1" },
  { key: "halogen", prompt: "Halogens belong to", expected: "Group 17" },
  { key: "noble", prompt: "Noble gases belong to", expected: "Group 18" },
  { key: "transition", prompt: "Transition elements are mainly", expected: "d-block" },
];

const activeSymbols = new Set(masteryElements.map((element) => element.symbol));
const elementMap = Object.fromEntries(masteryElements.map((element) => [element.symbol, element]));

const getBlockFromPosition = (symbol: string, group: number, period: number): Block => {
  if (lanthanides.includes(symbol) || actinides.includes(symbol) || period > 7) return "f";
  if (symbol === "He" || group <= 2) return "s";
  if (group >= 13) return "p";
  return "d";
};

const normalizeConfig = (value: string) =>
  value
    .replace(/\[[^\]]+\]/g, "")
    .replace(/\s+/g, " ")
    .trim();

const getFilledSubshells = (electrons: number) => {
  let remaining = electrons;
  const result: string[] = [];

  for (const orbital of orbitalOrder) {
    if (remaining <= 0) break;
    const fill = Math.min(remaining, orbital.capacity);
    result.push(`${orbital.name}${fill}`);
    remaining -= fill;
  }
  return result;
};

const getShellSummary = (subshells: string[]) => {
  const counts: Record<string, number> = { K: 0, L: 0, M: 0, N: 0, O: 0, P: 0, Q: 0 };
  subshells.forEach((entry) => {
    const match = entry.match(/^(\d)([spdf])(\d+)$/);
    if (!match) return;
    const shellIndex = Number(match[1]);
    const electronCount = Number(match[3]);
    const shellName = ["K", "L", "M", "N", "O", "P", "Q"][shellIndex - 1];
    counts[shellName] += electronCount;
  });
  return Object.entries(counts)
    .filter(([, value]) => value > 0)
    .map(([name, value]) => `${name}${value}`)
    .join(" ");
};

const shuffleQuestions = () => [...quizBank].sort(() => Math.random() - 0.5).slice(0, 12);

export default function App() {
  const [selectedSymbol, setSelectedSymbol] = useState("Na");
  const [forgeSymbol, setForgeSymbol] = useState("Na");
  const [forgeElectrons, setForgeElectrons] = useState(0);
  const [forgeFeedback, setForgeFeedback] = useState("");
  const [showSiren, setShowSiren] = useState(false);
  const [showStability, setShowStability] = useState(false);
  const [gaugeSymbol, setGaugeSymbol] = useState("Mg");
  const [battleId, setBattleId] = useState("k-na");
  const [trendMode, setTrendMode] = useState<"period3" | "group1">("period3");
  const [equationOne, setEquationOne] = useState(["", "", ""]);
  const [equationTwo, setEquationTwo] = useState(["", "", "", ""]);
  const [equationFeedback, setEquationFeedback] = useState("");
  const [metalNode, setMetalNode] = useState<"Fe" | "Ag">("Fe");
  const [showMysteryAnswer, setShowMysteryAnswer] = useState(false);
  const [timeMode, setTimeMode] = useState<"modern" | "mendeleev">("modern");
  const [libraryQuery, setLibraryQuery] = useState("");
  const [quizQuestions, setQuizQuestions] = useState<Question[]>(() => shuffleQuestions());
  const [quizAnswers, setQuizAnswers] = useState<Array<number | null>>(Array(12).fill(null));
  const [shortAnswers, setShortAnswers] = useState({ law: "", kion: "" });
  const [shortFeedback, setShortFeedback] = useState({ law: "", kion: "" });
  const [topicChecks, setTopicChecks] = useState<Record<string, boolean>>(
    Object.fromEntries(studyTopics.map((topic) => [topic.id, false])),
  );
  const [conceptKey, setConceptKey] = useState<keyof typeof conceptNotes>("period-vs-group");
  const [pairAnswers, setPairAnswers] = useState<Record<string, string>>({
    alkali: "",
    halogen: "",
    noble: "",
    transition: "",
  });
  const [pairFeedback, setPairFeedback] = useState("");
  const [predictSymbol, setPredictSymbol] = useState("Al");
  const [predictGroup, setPredictGroup] = useState("");
  const [predictPeriod, setPredictPeriod] = useState("");
  const [predictBlock, setPredictBlock] = useState("");
  const [predictFeedback, setPredictFeedback] = useState("");

  const selectedElement = elementMap[selectedSymbol];
  const forgeElement = elementMap[forgeSymbol];
  const gaugeElement = elementMap[gaugeSymbol];

  const theoreticalSubshell = getFilledSubshells(forgeElectrons);
  const theoreticalConfig = theoreticalSubshell.join(" ");

  const battles = [
    {
      id: "k-na",
      label: "K vs Na",
      left: "K",
      right: "Na",
      winner: "K",
      reason:
        "Potassium wins: its valence electron is in the 4th shell, farther from nucleus than sodium's 3rd shell electron, so it is lost faster.",
      size: [95, 74],
    },
    {
      id: "cl-br",
      label: "Cl vs Br",
      left: "Cl",
      right: "Br",
      winner: "Cl",
      reason:
        "Chlorine wins among non-metals: smaller radius means stronger nuclear pull on incoming electron, so reactivity is higher than bromine.",
      size: [64, 80],
    },
    {
      id: "f-i",
      label: "F vs I",
      left: "F",
      right: "I",
      winner: "F",
      reason:
        "Fluorine dominates due to extremely small size and strongest tendency to gain one electron.",
      size: [52, 92],
    },
  ];

  const activeBattle = battles.find((battle) => battle.id === battleId) ?? battles[0];

  const trendData =
    trendMode === "period3"
      ? [
          { symbol: "Na", size: 95 },
          { symbol: "Mg", size: 85 },
          { symbol: "Al", size: 78 },
          { symbol: "Si", size: 71 },
          { symbol: "P", size: 66 },
          { symbol: "S", size: 60 },
          { symbol: "Cl", size: 55 },
          { symbol: "Ar", size: 50 },
        ]
      : [
          { symbol: "Li", size: 50 },
          { symbol: "Na", size: 62 },
          { symbol: "K", size: 78 },
          { symbol: "Rb", size: 90 },
          { symbol: "Cs", size: 100 },
        ];

  const filteredLibrary = useMemo(
    () =>
      masteryElements.filter((element) => {
        const needle = libraryQuery.toLowerCase();
        return (
          element.name.toLowerCase().includes(needle) ||
          element.symbol.toLowerCase().includes(needle) ||
          String(element.atomicNumber).includes(needle)
        );
      }),
    [libraryQuery],
  );

  const answeredCount = quizAnswers.filter((value) => value !== null).length;
  const completedTopics = studyTopics.filter((topic) => topicChecks[topic.id]).length;
  const score = quizAnswers.reduce<number>((total, answer, index) => {
    if (answer === null) return total;
    return total + (answer === quizQuestions[index].answer ? 1 : 0);
  }, 0);

  const checkForge = () => {
    const real = normalizeConfig(forgeElement.subshell);
    const built = normalizeConfig(theoreticalConfig);
    if (forgeElectrons < forgeElement.atomicNumber) {
      setForgeFeedback("Keep building: the atom is not complete yet.");
      return;
    }
    if (real === built) {
      setForgeFeedback("Configuration check passed. Aufbau build matches the accepted configuration.");
      return;
    }
    if (forgeElement.symbol === "Cr" || forgeElement.symbol === "Cu") {
      setForgeFeedback(
        "Special exception detected: chromium and copper shift one 4s electron into 3d to gain half/full d-subshell stability.",
      );
      return;
    }
    setForgeFeedback("Mismatch found. Re-check sub-shell order and capacities.");
  };

  const checkEquations = () => {
    const oneCorrect = equationOne.join(",") === "3,1,1";
    const twoCorrect = equationTwo.join(",") === "1,2,1,1";
    if (oneCorrect && twoCorrect) {
      setEquationFeedback("Balanced correctly. You are SEE-ready for these reaction patterns.");
    } else {
      setEquationFeedback("Not balanced yet. Check atom counts on both sides and try again.");
    }
  };

  const checkShortAnswers = () => {
    const lawValid =
      shortAnswers.law.toLowerCase().includes("atomic") && shortAnswers.law.toLowerCase().includes("number");
    const kionValid =
      shortAnswers.kion.toLowerCase().includes("octet") || shortAnswers.kion.toLowerCase().includes("stable");

    setShortFeedback({
      law: lawValid
        ? "Accepted: you connected modern periodic law to atomic number."
        : "Root logic: mention that periodic properties depend on atomic number.",
      kion: kionValid
        ? "Accepted: K+ is favored due to stable noble-gas shell after one-electron loss."
        : "Root logic: explain octet stability after K loses one electron.",
    });
  };

  const checkClassificationPairs = () => {
    const allCorrect = classificationPairs.every((pair) => pairAnswers[pair.key] === pair.expected);
    setPairFeedback(
      allCorrect
        ? "Excellent. All classification statements are matched correctly."
        : "Some matches are incorrect. Recheck groups and blocks, then try again.",
    );
  };

  const checkPrediction = () => {
    const target = elementMap[predictSymbol];
    const groupOk = Number(predictGroup) === target.group;
    const periodOk = Number(predictPeriod) === target.period;
    const blockOk = predictBlock.toLowerCase() === target.block;

    if (groupOk && periodOk && blockOk) {
      setPredictFeedback(`Correct. ${target.symbol} is Group ${target.group}, Period ${target.period}, ${target.block}-block.`);
      return;
    }
    setPredictFeedback(
      `Try again. Correct answer: Group ${target.group}, Period ${target.period}, ${target.block}-block. Use shell count for period and valence pattern for group.`,
    );
  };

  return (
    <div className="min-h-screen bg-[#05040d] text-slate-100">
      <section className="hero-grid relative flex min-h-screen items-end overflow-hidden px-6 pb-16 pt-24 md:px-12 lg:px-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_10%,rgba(255,120,80,0.24),transparent_44%),linear-gradient(180deg,#0b1026_0%,#090414_55%,#04020a_100%)]" />
        <motion.div
          className="absolute left-1/2 top-10 h-64 w-64 -translate-x-1/2 rounded-full border border-amber-300/35"
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 18, ease: "linear" }}
        >
          <div className="absolute inset-3 rounded-full border border-amber-200/30" />
          <div className="absolute inset-6 rounded-full border border-orange-300/30" />
        </motion.div>
        <motion.div
          className="sun-core absolute left-1/2 top-16 h-44 w-44 -translate-x-1/2 rounded-full"
          animate={{ scale: [1, 1.08, 1] }}
          transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
        />
        <div className="relative z-10 max-w-4xl space-y-6">
          <p className="text-sm uppercase tracking-[0.3em] text-cyan-200/80">Grade 10 Unit 14 Study Platform</p>
          <h1 className="text-4xl font-black uppercase tracking-tight text-white md:text-6xl">
            Claasification of Elements
          </h1>
          <p className="max-w-2xl text-lg text-cyan-100/90 md:text-xl">Interactive Study Companion for SEE</p>
          <p className="max-w-3xl text-sm leading-relaxed text-slate-200 md:text-base">
            A structured Class 10 learning interface for periodic classification roots, sub-shell logic, valency,
            periodic trends, metallurgy links, and SEE-level question practice.
          </p>
        </div>
      </section>

      <main className="space-y-16 px-4 py-12 md:px-8 lg:px-12">
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-amber-200">Interactive Periodic Table</h2>
          <p className="max-w-4xl text-sm text-slate-300">
            Complete 118-element layout. H-Zn plus Ag, Au, and Hg are high-resolution nodes. Color coding: s blue, p
            green, d gold, f violet, noble gases neon pink.
          </p>
          <p className="text-xs text-slate-300">
            Group numbers are shown on top, period numbers on the left, and each element color shows its block.
          </p>
          <div className="overflow-x-auto rounded-xl border border-amber-300/25 bg-[#0b0a16]/80 p-3">
            <div className="min-w-[1110px] space-y-2">
              <div className="flex items-center gap-1 text-[10px] text-amber-100/80">
                <div className="w-10 text-center">Period</div>
                <div className="grid flex-1 grid-cols-[repeat(18,minmax(0,1fr))] gap-1">
                  {Array.from({ length: 18 }, (_, group) => (
                    <div key={`group-${group + 1}`} className="text-center">
                      G{group + 1}
                    </div>
                  ))}
                </div>
              </div>
              {periodRows.map((row, rowIndex) => (
                <div key={`period-${rowIndex + 1}`} className="flex items-center gap-1">
                  <div className="w-10 text-center text-xs font-semibold text-amber-100/80">P{rowIndex + 1}</div>
                  <div className="grid flex-1 grid-cols-[repeat(18,minmax(0,1fr))] gap-1">
                    {row.map((symbol, colIndex) => {
                      if (!symbol) {
                        return <div key={`empty-${rowIndex}-${colIndex}`} className="h-12 rounded border border-transparent" />;
                      }
                      const detail = elementMap[symbol];
                      const block = getBlockFromPosition(symbol, colIndex + 1, rowIndex + 1);
                      const isActive = activeSymbols.has(symbol);
                      const noble = nobleGases.has(symbol);

                      return (
                        <motion.button
                          whileHover={{ y: -2 }}
                          whileTap={{ scale: 0.98 }}
                          key={symbol}
                          onClick={() => isActive && setSelectedSymbol(symbol)}
                          className={`h-12 rounded border text-xs font-semibold ${
                            noble
                              ? "border-pink-400 bg-pink-400/15 text-pink-200"
                              : blockColors[block]
                          } ${isActive ? "cursor-pointer" : "cursor-default opacity-35"} transition`}
                          disabled={!isActive}
                          title={isActive ? `${detail?.name}` : `Atomic number ${symbolToAtomic[symbol]}`}
                        >
                          <div className="leading-tight">
                            <p>{symbol}</p>
                            <p className="text-[10px] opacity-80">{symbolToAtomic[symbol]}</p>
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>
                </div>
              ))}
              <div className="grid grid-cols-4 gap-2 pt-2 text-[11px]">
                <div className="rounded border border-[#4cc9ff] px-2 py-1 text-[#96e6ff]">s-block: Groups 1-2 (+He)</div>
                <div className="rounded border border-[#ffd166] px-2 py-1 text-[#ffe5a3]">d-block: Groups 3-12</div>
                <div className="rounded border border-[#37f28f] px-2 py-1 text-[#93ffbd]">p-block: Groups 13-18</div>
                <div className="rounded border border-[#b388ff] px-2 py-1 text-[#d4b8ff]">f-block: Lanthanides and Actinides</div>
              </div>
              <div className="mt-4 space-y-1">
                <p className="text-xs uppercase tracking-widest text-violet-200/80">Lanthanides</p>
                <div className="flex items-center gap-1">
                  <div className="w-10 text-center text-xs font-semibold text-violet-200/70">P6*</div>
                  <div className="grid flex-1 grid-cols-[repeat(18,minmax(0,1fr))] gap-1">
                    <div className="col-span-3" />
                  {lanthanides.map((symbol) => (
                    <div key={symbol} className="h-12 rounded border border-[#b388ff] bg-[#b388ff1a] text-center text-xs font-semibold text-violet-200 opacity-45">
                      <p>{symbol}</p>
                      <p className="text-[10px]">{symbolToAtomic[symbol]}</p>
                    </div>
                  ))}
                  </div>
                </div>
                <p className="text-xs uppercase tracking-widest text-violet-200/80">Actinides</p>
                <div className="flex items-center gap-1">
                  <div className="w-10 text-center text-xs font-semibold text-violet-200/70">P7*</div>
                  <div className="grid flex-1 grid-cols-[repeat(18,minmax(0,1fr))] gap-1">
                    <div className="col-span-3" />
                  {actinides.map((symbol) => (
                    <div key={symbol} className="h-12 rounded border border-[#b388ff] bg-[#b388ff1a] text-center text-xs font-semibold text-violet-200 opacity-45">
                      <p>{symbol}</p>
                      <p className="text-[10px]">{symbolToAtomic[symbol]}</p>
                    </div>
                  ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-cyan-300/35 bg-[#0a1320]/80 p-4">
            <h3 className="text-xl font-bold text-cyan-100">
              {selectedElement.name} ({selectedElement.symbol})
            </h3>
            <p className="text-sm text-cyan-50/90">Sub-shell configuration: {selectedElement.subshell}</p>
            <p className="text-sm text-cyan-50/90">Shell configuration: {selectedElement.shell}</p>
            <p className="text-sm text-cyan-50/90">
              Group {selectedElement.group}, Period {selectedElement.period}, {selectedElement.block}-block
            </p>
            <p className="text-sm text-cyan-50/90">Valency: {selectedElement.valency}</p>
            <p className="mt-2 text-sm text-slate-200">Block traits: {selectedElement.traits}</p>
            <p className="mt-2 text-sm text-slate-200">Position logic: {selectedElement.why}</p>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-xl border border-fuchsia-400/35 bg-[#1a0d28]/70 p-4 text-sm text-fuchsia-100">
              <p className="font-semibold">Modern Periodic Law</p>
              <p>Properties of elements are periodic functions of atomic number, so electron arrangement repeats in a pattern.</p>
            </div>
            <div className="rounded-xl border border-amber-400/35 bg-[#22150a]/70 p-4 text-sm text-amber-100">
              <p className="font-semibold">Argon-Potassium Pair</p>
              <p>In atomic mass ordering, K appears before Ar. Modern ordering by atomic number fixes this and keeps group properties correct.</p>
            </div>
          </div>
        </section>

        <section className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-4 rounded-xl border border-cyan-400/35 bg-[#071527]/80 p-4">
            <h2 className="text-2xl font-bold text-cyan-100">Sub-shell Builder</h2>
            <p className="text-sm text-slate-300">Build electron filling in Aufbau order and verify against accepted configurations.</p>
            <div className="flex flex-wrap items-center gap-3">
              <select
                value={forgeSymbol}
                onChange={(event) => {
                  setForgeSymbol(event.target.value);
                  setForgeElectrons(0);
                  setForgeFeedback("");
                }}
                className="rounded border border-cyan-300/40 bg-[#02070f] px-3 py-2 text-sm"
              >
                {masteryElements.map((element) => (
                  <option key={element.symbol} value={element.symbol}>
                    {element.symbol} - {element.name}
                  </option>
                ))}
              </select>
              <button
                onClick={() => setForgeElectrons((value) => Math.min(value + 1, forgeElement.atomicNumber))}
                className="rounded border border-cyan-300/60 bg-cyan-500/15 px-3 py-2 text-sm"
              >
                Add Electron
              </button>
              <button
                onClick={() => {
                  setShowSiren(true);
                    setForgeFeedback("Aufbau rule check: 2s must be complete before 2p starts.");
                }}
                className="rounded border border-rose-300/60 bg-rose-500/15 px-3 py-2 text-sm"
              >
                Check Aufbau Rule
              </button>
              <button
                onClick={() => setShowStability((value) => !value)}
                className="rounded border border-amber-300/60 bg-amber-500/15 px-3 py-2 text-sm"
              >
                Sodium vs Magnesium Stability
              </button>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              <div className="rounded border border-cyan-300/20 p-3">
                <p className="text-xs uppercase tracking-wider text-cyan-200">Orbital Clouds</p>
                <div className="mt-3 flex items-center gap-4">
                  <div className="h-14 w-14 rounded-full border border-cyan-200/60 bg-cyan-300/15" />
                  <div className="flex items-center">
                    <div className="h-8 w-8 rounded-full border border-cyan-200/60 bg-cyan-300/15" />
                    <div className="-ml-2 h-8 w-8 rounded-full border border-cyan-200/60 bg-cyan-300/15" />
                  </div>
                </div>
                <p className="mt-2 text-xs text-slate-300">s orbitals are spherical, p orbitals are dumbbell-like.</p>
              </div>
              <div className="rounded border border-cyan-300/20 p-3 text-sm">
                <p>Target electrons: {forgeElement.atomicNumber}</p>
                <p>Built electrons: {forgeElectrons}</p>
                <p className="mt-2 text-cyan-100">Built sub-shell: {theoreticalConfig || "None yet"}</p>
                <p className="mt-1 text-cyan-100">Live shell summary: {getShellSummary(theoreticalSubshell) || "None"}</p>
              </div>
            </div>
            <button
              onClick={checkForge}
              className="rounded border border-cyan-300/60 bg-cyan-500/20 px-3 py-2 text-sm"
            >
              Check Configuration
            </button>
            {(forgeFeedback || showSiren) && <p className="text-sm text-cyan-100">{forgeFeedback}</p>}
            <AnimatePresence>
              {showStability && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 8 }}
                  className="rounded border border-amber-300/40 bg-[#22150a]/80 p-3 text-sm text-amber-100"
                >
                  Na can form Na+ by losing 3s1, then reaches stable octet (2,8). Na2+ is highly unstable because it
                  would require breaking the full second shell. Mg naturally forms Mg2+ because losing two 3s electrons
                  directly reaches the same stable octet core.
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="space-y-4 rounded-xl border border-amber-300/35 bg-[#1a1207]/80 p-4">
            <h2 className="text-2xl font-bold text-amber-100">Valency Shield</h2>
            <p className="text-sm text-slate-300">Animated brass gauge for valence electron insight and ion logic.</p>
            <select
              value={gaugeSymbol}
              onChange={(event) => setGaugeSymbol(event.target.value)}
              className="rounded border border-amber-300/40 bg-[#0f0903] px-3 py-2 text-sm"
            >
              {masteryElements.map((element) => (
                <option key={element.symbol} value={element.symbol}>
                  {element.symbol} - {element.name}
                </option>
              ))}
            </select>
            <div className="flex flex-col gap-4 md:flex-row md:items-center">
              <div className="relative h-48 w-48 rounded-full border-4 border-amber-300/50 bg-[#130b02]">
                <div className="absolute inset-4 rounded-full border border-amber-200/40" />
                <motion.div
                  className="absolute left-1/2 top-1/2 h-1 w-16 origin-left rounded bg-red-400"
                  animate={{ rotate: -90 + (gaugeElement.outerElectrons / 8) * 180 }}
                  transition={{ type: "spring", stiffness: 120, damping: 14 }}
                />
                <div className="absolute bottom-5 left-1/2 -translate-x-1/2 text-xs text-amber-100">
                  Valence e-: {gaugeElement.outerElectrons}
                </div>
              </div>
              <div className="space-y-2 text-sm text-amber-100">
                <p>Outer shell electrons: {gaugeElement.outerElectrons}</p>
                <p>Likely ion behavior: {gaugeElement.losesGains}</p>
                <p>Valency: {gaugeElement.valency}</p>
                <p>Reasoning: {gaugeElement.why}</p>
              </div>
            </div>
          </div>
        </section>

        <section className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-4 rounded-xl border border-green-300/35 bg-[#07190e]/80 p-4">
            <h2 className="text-2xl font-bold text-green-100">Reactivity Comparison</h2>
            <p className="text-sm text-slate-300">Direct comparison of metals and non-metals using radius and nuclear attraction.</p>
            <div className="flex flex-wrap gap-2">
              {battles.map((battle) => (
                <button
                  key={battle.id}
                  onClick={() => setBattleId(battle.id)}
                  className={`rounded border px-3 py-2 text-sm ${
                    battle.id === battleId
                      ? "border-green-200 bg-green-400/25 text-green-100"
                      : "border-green-300/35 bg-transparent text-green-200"
                  }`}
                >
                  {battle.label}
                </button>
              ))}
            </div>
            <div className="flex items-end justify-center gap-8 rounded border border-green-300/25 p-4">
              <motion.div
                key={`${activeBattle.left}-${activeBattle.size[0]}`}
                initial={{ scale: 0.6, opacity: 0.5 }}
                animate={{ scale: 1, opacity: 1 }}
                className="flex flex-col items-center"
              >
                <div
                  className="rounded-full border border-green-200/60 bg-green-300/20"
                  style={{ width: `${activeBattle.size[0]}px`, height: `${activeBattle.size[0]}px` }}
                />
                <p className="mt-2 text-sm">{activeBattle.left}</p>
              </motion.div>
              <motion.div
                key={`${activeBattle.right}-${activeBattle.size[1]}`}
                initial={{ scale: 0.6, opacity: 0.5 }}
                animate={{ scale: 1, opacity: 1 }}
                className="flex flex-col items-center"
              >
                <div
                  className="rounded-full border border-green-200/60 bg-green-300/20"
                  style={{ width: `${activeBattle.size[1]}px`, height: `${activeBattle.size[1]}px` }}
                />
                <p className="mt-2 text-sm">{activeBattle.right}</p>
              </motion.div>
            </div>
            <p className="text-sm text-green-100">More reactive element: {activeBattle.winner}</p>
            <p className="text-sm text-slate-200">{activeBattle.reason}</p>
            <div className="rounded border border-green-300/30 bg-green-600/10 p-3 text-sm text-green-100">
              Core concept: Group 1 metals lose one electron to reach noble gas stability. Forming 2+ would remove an
              electron from a stable filled shell and requires very high energy.
            </div>
          </div>

          <div className="space-y-4 rounded-xl border border-violet-300/35 bg-[#13081b]/80 p-4">
            <h2 className="text-2xl font-bold text-violet-100">Atomic Radius Trends</h2>
            <p className="text-sm text-slate-300">Move across Period 3 or down Group 1 and observe atomic radius changes.</p>
            <div className="flex gap-2">
              <button
                onClick={() => setTrendMode("period3")}
                className={`rounded border px-3 py-2 text-sm ${
                  trendMode === "period3"
                    ? "border-violet-200 bg-violet-400/25 text-violet-100"
                    : "border-violet-300/35 text-violet-200"
                }`}
              >
                Across Period 3
              </button>
              <button
                onClick={() => setTrendMode("group1")}
                className={`rounded border px-3 py-2 text-sm ${
                  trendMode === "group1"
                    ? "border-violet-200 bg-violet-400/25 text-violet-100"
                    : "border-violet-300/35 text-violet-200"
                }`}
              >
                Down Group 1
              </button>
            </div>
            <div className="flex flex-wrap items-end gap-3 rounded border border-violet-300/25 p-3">
              {trendData.map((point, index) => (
                <motion.div
                  key={`${trendMode}-${point.symbol}`}
                  initial={{ scale: 0.5, opacity: 0.4 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex flex-col items-center"
                >
                  <div
                    className="rounded-full border border-violet-200/65 bg-violet-300/20"
                    style={{ width: `${point.size}px`, height: `${point.size}px` }}
                  />
                  <p className="mt-2 text-xs text-violet-100">{point.symbol}</p>
                </motion.div>
              ))}
            </div>
            <p className="text-sm text-slate-200">
              {trendMode === "period3"
                ? "Across a period, electrons enter the same shell while nuclear charge increases, so atoms shrink."
                : "Down a group, new shells are added, increasing distance from nucleus and atomic radius."}
            </p>
          </div>
        </section>

        <section className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-4 rounded-xl border border-blue-300/35 bg-[#081225]/80 p-4">
            <h2 className="text-2xl font-bold text-blue-100">Equation Practice</h2>
            <p className="text-sm text-slate-300">Balance standard SEE-paper reactions by entering coefficients.</p>
            <div className="space-y-3 text-sm text-blue-100">
              <div className="flex flex-wrap items-center gap-2">
                <input
                  value={equationOne[0]}
                  onChange={(event) => setEquationOne([event.target.value, equationOne[1], equationOne[2]])}
                  className="w-12 rounded border border-blue-300/40 bg-[#03080f] px-2 py-1"
                />
                <span>Mg +</span>
                <input
                  value={equationOne[1]}
                  onChange={(event) => setEquationOne([equationOne[0], event.target.value, equationOne[2]])}
                  className="w-12 rounded border border-blue-300/40 bg-[#03080f] px-2 py-1"
                />
                <span>N2 -&gt;</span>
                <input
                  value={equationOne[2]}
                  onChange={(event) => setEquationOne([equationOne[0], equationOne[1], event.target.value])}
                  className="w-12 rounded border border-blue-300/40 bg-[#03080f] px-2 py-1"
                />
                <span>Mg3N2</span>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <input
                  value={equationTwo[0]}
                  onChange={(event) => setEquationTwo([event.target.value, equationTwo[1], equationTwo[2], equationTwo[3]])}
                  className="w-12 rounded border border-blue-300/40 bg-[#03080f] px-2 py-1"
                />
                <span>Zn +</span>
                <input
                  value={equationTwo[1]}
                  onChange={(event) => setEquationTwo([equationTwo[0], event.target.value, equationTwo[2], equationTwo[3]])}
                  className="w-12 rounded border border-blue-300/40 bg-[#03080f] px-2 py-1"
                />
                <span>HCl -&gt;</span>
                <input
                  value={equationTwo[2]}
                  onChange={(event) => setEquationTwo([equationTwo[0], equationTwo[1], event.target.value, equationTwo[3]])}
                  className="w-12 rounded border border-blue-300/40 bg-[#03080f] px-2 py-1"
                />
                <span>ZnCl2 +</span>
                <input
                  value={equationTwo[3]}
                  onChange={(event) => setEquationTwo([equationTwo[0], equationTwo[1], equationTwo[2], event.target.value])}
                  className="w-12 rounded border border-blue-300/40 bg-[#03080f] px-2 py-1"
                />
                <span>H2</span>
              </div>
            </div>
            <button
              onClick={checkEquations}
              className="rounded border border-blue-300/60 bg-blue-500/20 px-3 py-2 text-sm"
            >
              Check Balancing
            </button>
            {equationFeedback && <p className="text-sm text-blue-100">{equationFeedback}</p>}
          </div>

          <div className="space-y-4 rounded-xl border border-zinc-300/35 bg-[#101114]/85 p-4">
            <h2 className="text-2xl font-bold text-zinc-100">Metallurgy Node</h2>
            <p className="text-sm text-slate-300">Bridge Unit 14 classification with Unit 17 metal extraction methods.</p>
            <div className="flex gap-2">
              <button
                onClick={() => setMetalNode("Fe")}
                className={`rounded border px-3 py-2 text-sm ${
                  metalNode === "Fe"
                    ? "border-zinc-100 bg-zinc-500/25 text-zinc-100"
                    : "border-zinc-400/40 text-zinc-200"
                }`}
              >
                Iron (Fe)
              </button>
              <button
                onClick={() => setMetalNode("Ag")}
                className={`rounded border px-3 py-2 text-sm ${
                  metalNode === "Ag"
                    ? "border-zinc-100 bg-zinc-500/25 text-zinc-100"
                    : "border-zinc-400/40 text-zinc-200"
                }`}
              >
                Silver (Ag)
              </button>
            </div>
            {metalNode === "Fe" ? (
              <p className="text-sm text-zinc-100">
                Iron ores: Hematite (Fe2O3) and Magnetite (Fe3O4). Roasting/calcination helps remove impurities and
                convert sulfides before blast-furnace reduction to iron.
              </p>
            ) : (
              <p className="text-sm text-zinc-100">
                Silver electro-refining: impure Ag as anode, pure Ag sheet as cathode, AgNO3 solution as electrolyte.
                Silver deposits at cathode while impurities settle as anode mud.
              </p>
            )}
          </div>
        </section>

        <section className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-4 rounded-xl border border-rose-300/35 bg-[#200811]/80 p-4">
            <h2 className="text-2xl font-bold text-rose-100">Coordinate Practice Grid</h2>
            <p className="text-sm text-slate-300">Decode X, Y, Z, a, b, c using periodic coordinates and infer valency/reactivity.</p>
            <div className="grid grid-cols-3 gap-2 text-center text-sm">
              <div className="rounded border border-rose-300/35 p-3">X (G1, P3)</div>
              <div className="rounded border border-rose-300/35 p-3">Y (G2, P3)</div>
              <div className="rounded border border-rose-300/35 p-3">Z (G17, P3)</div>
              <div className="rounded border border-rose-300/35 p-3">a (G1, P4)</div>
              <div className="rounded border border-rose-300/35 p-3">b (G17, P2)</div>
              <div className="rounded border border-rose-300/35 p-3">c (G18, P3)</div>
            </div>
            <button
              onClick={() => setShowMysteryAnswer((value) => !value)}
              className="rounded border border-rose-300/60 bg-rose-500/20 px-3 py-2 text-sm"
            >
              {showMysteryAnswer ? "Hide" : "Reveal"} Identities
            </button>
            {showMysteryAnswer && (
              <p className="text-sm text-rose-100">
                X=Na (valency 1), Y=Mg (valency 2), Z=Cl (valency 1), a=K (more reactive than Na), b=F (more reactive
                than Cl), c=Ar (valency 0).
              </p>
            )}
          </div>

          <div className="space-y-4 rounded-xl border border-sky-300/35 bg-[#081b24]/80 p-4">
            <h2 className="text-2xl font-bold text-sky-100">Historical vs Modern Arrangement</h2>
            <p className="text-sm text-slate-300">Switch between Mendeleev mass-order and Modern atomic-number order.</p>
            <div className="flex gap-2">
              <button
                onClick={() => setTimeMode("mendeleev")}
                className={`rounded border px-3 py-2 text-sm ${
                  timeMode === "mendeleev"
                    ? "border-sky-100 bg-sky-500/25 text-sky-100"
                    : "border-sky-300/40 text-sky-200"
                }`}
              >
                Mendeleev Order
              </button>
              <button
                onClick={() => setTimeMode("modern")}
                className={`rounded border px-3 py-2 text-sm ${
                  timeMode === "modern"
                    ? "border-sky-100 bg-sky-500/25 text-sky-100"
                    : "border-sky-300/40 text-sky-200"
                }`}
              >
                Modern Order
              </button>
            </div>
            <div className="flex items-center gap-3 rounded border border-sky-300/25 p-3">
              <motion.div
                layout
                className="rounded border border-sky-200/40 bg-sky-400/15 px-3 py-2 text-sm"
              >
                {timeMode === "mendeleev" ? "K (39.1)" : "Ar (18)"}
              </motion.div>
              <motion.div
                layout
                className="rounded border border-sky-200/40 bg-sky-400/15 px-3 py-2 text-sm"
              >
                {timeMode === "mendeleev" ? "Ar (39.9)" : "K (19)"}
              </motion.div>
            </div>
            <p className="text-sm text-sky-100">
              {timeMode === "mendeleev"
                ? "Glitch shown: atomic mass order places K before Ar, breaking group behavior."
                : "Resolved: atomic number order places Ar in Group 18 and K in Group 1 correctly."}
            </p>
          </div>
        </section>

        <section className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-4 rounded-xl border border-indigo-300/35 bg-[#0a1026]/80 p-4">
            <h2 className="text-2xl font-bold text-indigo-100">Chapter Coverage Tracker</h2>
            <p className="text-sm text-slate-300">
              Mark each topic after you understand it. This keeps revision complete for Class 10 exams.
            </p>
            <div className="space-y-2">
              {studyTopics.map((topic) => (
                <label key={topic.id} className="flex items-center gap-2 text-sm text-indigo-50">
                  <input
                    type="checkbox"
                    checked={topicChecks[topic.id]}
                    onChange={(event) =>
                      setTopicChecks((prev) => ({
                        ...prev,
                        [topic.id]: event.target.checked,
                      }))
                    }
                    className="h-4 w-4 accent-indigo-400"
                  />
                  {topic.label}
                </label>
              ))}
            </div>
            <div className="rounded border border-indigo-300/30 p-3 text-sm text-indigo-100">
              Coverage progress: {completedTopics}/{studyTopics.length} topics completed
              <div className="mt-2 h-2 w-full overflow-hidden rounded bg-indigo-950">
                <motion.div
                  className="h-full bg-indigo-300"
                  animate={{ width: `${(completedTopics / studyTopics.length) * 100}%` }}
                />
              </div>
            </div>
          </div>

          <div className="space-y-4 rounded-xl border border-cyan-300/35 bg-[#081721]/80 p-4">
            <h2 className="text-2xl font-bold text-cyan-100">Concept Clarifier</h2>
            <p className="text-sm text-slate-300">Select a core concept and read exam-ready explanation in simple language.</p>
            <div className="flex flex-wrap gap-2">
              {(Object.keys(conceptNotes) as Array<keyof typeof conceptNotes>).map((key) => (
                <button
                  key={key}
                  onClick={() => setConceptKey(key)}
                  className={`rounded border px-3 py-2 text-xs md:text-sm ${
                    conceptKey === key
                      ? "border-cyan-200 bg-cyan-500/25 text-cyan-100"
                      : "border-cyan-300/35 text-cyan-200"
                  }`}
                >
                  {conceptNotes[key].title}
                </button>
              ))}
            </div>
            <div className="rounded border border-cyan-300/30 p-3 text-sm text-cyan-50">
              <p className="font-semibold">{conceptNotes[conceptKey].title}</p>
              <p className="mt-2">{conceptNotes[conceptKey].text}</p>
              <p className="mt-2 text-cyan-100">Exam Focus: {conceptNotes[conceptKey].exam}</p>
            </div>
          </div>
        </section>

        <section className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-4 rounded-xl border border-orange-300/35 bg-[#1e1206]/80 p-4">
            <h2 className="text-2xl font-bold text-orange-100">Classification Drill</h2>
            <p className="text-sm text-slate-300">Match the statement with the correct group or block.</p>
            <div className="space-y-3">
              {classificationPairs.map((pair) => (
                <div key={pair.key} className="grid gap-2 md:grid-cols-2 md:items-center">
                  <p className="text-sm text-orange-50">{pair.prompt}</p>
                  <select
                    value={pairAnswers[pair.key]}
                    onChange={(event) =>
                      setPairAnswers((prev) => ({
                        ...prev,
                        [pair.key]: event.target.value,
                      }))
                    }
                    className="rounded border border-orange-300/40 bg-[#0f0903] px-3 py-2 text-sm"
                  >
                    <option value="">Select answer</option>
                    <option value="Group 1">Group 1</option>
                    <option value="Group 17">Group 17</option>
                    <option value="Group 18">Group 18</option>
                    <option value="d-block">d-block</option>
                    <option value="p-block">p-block</option>
                  </select>
                </div>
              ))}
            </div>
            <button
              onClick={checkClassificationPairs}
              className="rounded border border-orange-300/60 bg-orange-500/20 px-3 py-2 text-sm"
            >
              Check Matching
            </button>
            {pairFeedback && <p className="text-sm text-orange-100">{pairFeedback}</p>}
          </div>

          <div className="space-y-4 rounded-xl border border-fuchsia-300/35 bg-[#1a0822]/80 p-4">
            <h2 className="text-2xl font-bold text-fuchsia-100">Position Prediction Practice</h2>
            <p className="text-sm text-slate-300">
              Predict group, period, and block from your understanding, then verify instantly.
            </p>
            <select
              value={predictSymbol}
              onChange={(event) => {
                setPredictSymbol(event.target.value);
                setPredictFeedback("");
              }}
              className="rounded border border-fuchsia-300/40 bg-[#100411] px-3 py-2 text-sm"
            >
              {["Na", "Mg", "Al", "Cl", "K", "Ca", "Fe", "Cu", "Zn", "Ag"].map((symbol) => (
                <option key={symbol} value={symbol}>
                  {symbol} - {elementMap[symbol].name}
                </option>
              ))}
            </select>
            <div className="grid gap-2 md:grid-cols-3">
              <input
                value={predictGroup}
                onChange={(event) => setPredictGroup(event.target.value)}
                placeholder="Group"
                className="rounded border border-fuchsia-300/40 bg-[#100411] px-3 py-2 text-sm"
              />
              <input
                value={predictPeriod}
                onChange={(event) => setPredictPeriod(event.target.value)}
                placeholder="Period"
                className="rounded border border-fuchsia-300/40 bg-[#100411] px-3 py-2 text-sm"
              />
              <input
                value={predictBlock}
                onChange={(event) => setPredictBlock(event.target.value)}
                placeholder="Block (s/p/d/f)"
                className="rounded border border-fuchsia-300/40 bg-[#100411] px-3 py-2 text-sm"
              />
            </div>
            <button
              onClick={checkPrediction}
              className="rounded border border-fuchsia-300/60 bg-fuchsia-500/20 px-3 py-2 text-sm"
            >
              Check Prediction
            </button>
            {predictFeedback && <p className="text-sm text-fuchsia-100">{predictFeedback}</p>}
          </div>
        </section>

        <section className="space-y-4 rounded-xl border border-teal-300/35 bg-[#051a1a]/80 p-4">
          <h2 className="text-2xl font-bold text-teal-100">Library of Elements</h2>
          <p className="text-sm text-slate-300">Searchable mastery dataset for 33 SEE-focus elements (1-30 plus Ag, Au, Hg).</p>
          <input
            value={libraryQuery}
            onChange={(event) => setLibraryQuery(event.target.value)}
            placeholder="Search by name, symbol, or atomic number"
            className="w-full rounded border border-teal-300/40 bg-[#021010] px-3 py-2 text-sm"
          />
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-xs md:text-sm">
              <thead>
                <tr className="border-b border-teal-200/25 text-teal-100">
                  <th className="px-2 py-2">Z</th>
                  <th className="px-2 py-2">Element</th>
                  <th className="px-2 py-2">Sub-shell</th>
                  <th className="px-2 py-2">Shell</th>
                  <th className="px-2 py-2">Valency</th>
                  <th className="px-2 py-2">Group</th>
                  <th className="px-2 py-2">Period</th>
                  <th className="px-2 py-2">Block</th>
                </tr>
              </thead>
              <tbody>
                {filteredLibrary.map((element) => (
                  <tr key={element.symbol} className="border-b border-teal-100/10 text-teal-50">
                    <td className="px-2 py-2">{element.atomicNumber}</td>
                    <td className="px-2 py-2">{element.name} ({element.symbol})</td>
                    <td className="px-2 py-2">{element.subshell}</td>
                    <td className="px-2 py-2">{element.shell}</td>
                    <td className="px-2 py-2">{element.valency}</td>
                    <td className="px-2 py-2">{element.group}</td>
                    <td className="px-2 py-2">{element.period}</td>
                    <td className="px-2 py-2">{element.block}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="space-y-4 rounded-xl border border-lime-300/35 bg-[#101b07]/80 p-4">
          <h2 className="text-2xl font-bold text-lime-100">SEE Exam Practice</h2>
          <p className="text-sm text-slate-300">
            12 randomized MCQs from a 20-question bank. Immediate root-logic feedback appears after each response.
          </p>
          <div className="space-y-4">
            {quizQuestions.map((question, index) => {
              const selected = quizAnswers[index];
              return (
                <div key={`${question.prompt}-${index}`} className="rounded border border-lime-300/25 p-3">
                  <p className="text-sm text-lime-50">
                    {index + 1}. {question.prompt}
                  </p>
                  <div className="mt-2 grid gap-2 md:grid-cols-2">
                    {question.options.map((option, optionIndex) => (
                      <button
                        key={option}
                        onClick={() => {
                          const next = [...quizAnswers];
                          next[index] = optionIndex;
                          setQuizAnswers(next);
                        }}
                        className={`rounded border px-2 py-2 text-left text-xs md:text-sm ${
                          selected === optionIndex
                            ? optionIndex === question.answer
                              ? "border-lime-200 bg-lime-500/20 text-lime-100"
                              : "border-rose-200 bg-rose-500/20 text-rose-100"
                            : "border-lime-300/25 text-lime-100"
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                  {selected !== null && (
                    <p className="mt-2 text-xs text-slate-200">
                      {selected === question.answer ? "Correct." : "Incorrect."} {question.explanation}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
          <div className="space-y-3 rounded border border-lime-200/20 p-3">
            <p className="text-sm font-semibold text-lime-100">Short Answer Drill</p>
            <label className="block text-xs text-lime-50">
              1) State Modern Periodic Law in one sentence.
              <textarea
                value={shortAnswers.law}
                onChange={(event) => setShortAnswers({ ...shortAnswers, law: event.target.value })}
                className="mt-1 w-full rounded border border-lime-300/30 bg-[#090f04] p-2 text-xs"
                rows={2}
              />
            </label>
            {shortFeedback.law && <p className="text-xs text-slate-200">{shortFeedback.law}</p>}
            <label className="block text-xs text-lime-50">
              2) Why does potassium not form K2+ easily?
              <textarea
                value={shortAnswers.kion}
                onChange={(event) => setShortAnswers({ ...shortAnswers, kion: event.target.value })}
                className="mt-1 w-full rounded border border-lime-300/30 bg-[#090f04] p-2 text-xs"
                rows={2}
              />
            </label>
            {shortFeedback.kion && <p className="text-xs text-slate-200">{shortFeedback.kion}</p>}
            <button
              onClick={checkShortAnswers}
              className="rounded border border-lime-200/60 bg-lime-500/20 px-3 py-2 text-xs"
            >
              Check Short Answers
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <p className="text-sm text-lime-100">
              Progress: {answeredCount}/12 | Score: {score}/12
            </p>
            <button
              onClick={() => {
                setQuizQuestions(shuffleQuestions());
                setQuizAnswers(Array(12).fill(null));
                setShortAnswers({ law: "", kion: "" });
                setShortFeedback({ law: "", kion: "" });
                setPairAnswers({ alkali: "", halogen: "", noble: "", transition: "" });
                setPairFeedback("");
              }}
              className="rounded border border-lime-200/60 bg-lime-500/20 px-3 py-2 text-sm"
            >
              Retry New Set
            </button>
          </div>
        </section>
      </main>
      <footer className="px-4 pb-10 text-center text-xs text-slate-400 md:px-8 lg:px-12">
        Claasification of Elements | Copyright by Baibhav Bhatta
      </footer>
    </div>
  );
}
